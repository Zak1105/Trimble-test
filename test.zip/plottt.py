import matplotlib.pyplot as plt
import numpy as np

x=[0,4,8,16]
y=np.sqrt(x)
plt.plot(x,y)
plt.show()